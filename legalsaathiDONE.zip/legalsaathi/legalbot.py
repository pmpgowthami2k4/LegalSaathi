# from flask import Flask, request, jsonify
# import openai
# from flask_cors import CORS
# import random
# from firebaseconfig import store_message
# from firebaseconfig import get_user_messages

# app = Flask(__name__)
# CORS(app)

# api_key = "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"
# # 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

# openai_client = openai.OpenAI(
#     api_key=api_key,
#     base_url="https://openrouter.ai/api/v1"
# )

# # ✅ Emoji map specific to legal context
# def add_emoji(response):
#     emoji_map = {
#         "law": "📜",
#         "legal": "⚖️",
#         "rights": "🧾",
#         "justice": "⚖️",
#         "contract": "📝",
#         "help": "📘",
#         "court": "🏛️",
#         "advice": "💡"
#     }
#     for word, emoji in emoji_map.items():
#         if word in response.lower():
#             return f"{response} {emoji}"
#     return response

# @app.route("/chat", methods=["POST"])
# @app.route("/chat", methods=["POST"])
# def chat():
#     user_input = request.json.get("message", "")
#     user_id = request.json.get("userId", "anonymous")

#     if not user_input:
#         return jsonify({"error": "Empty message"}), 400

#     try:
#         # ✅ Use strong and very specific system prompt for legal tone
#         system_prompt = (
#             "You are Legal Saathi, a professional legal advisory assistant. "
#             "Your role is to provide general legal information in simple, clear terms. "
#             "You do NOT offer therapy, emotional support, or mental health advice. "
#             "If asked anything unrelated to legal rights, law, contracts, criminal offenses, civil issues, etc., "
#             "politely reply: 'I'm here to assist with legal questions. Could you please ask something related to law?'"
#         )

#         response = openai_client.chat.completions.create(
#             model="openai/gpt-3.5-turbo",
#             messages=[
#                 {"role": "system", "content": system_prompt},
#                 {"role": "user", "content": user_input}
#             ]
#         )

#         bot_reply = response.choices[0].message.content.strip()

#         # ✅ Store the message without emotional emoji tone
#         store_message(user_id, user_input, bot_reply)

#         return jsonify({"reply": bot_reply})

#     except Exception as e:
#         print("❌ Error processing request:", e)
#         return jsonify({"error": str(e)}), 500


# @app.route("/chat-history", methods=["GET"])
# def chat_history():
#     user_id = "test_user_123"
#     messages = get_user_messages(user_id)
#     return jsonify({"messages": messages})


# if __name__ == "__main__":
#     app.run(debug=True)


from flask import Flask, request, jsonify
import openai
from flask_cors import CORS
from firebaseconfig import store_message, get_user_messages
from ipcsections import ipc_sections

app = Flask(__name__)
CORS(app)

api_key = "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"

openai_client = openai.OpenAI(
    api_key=api_key,
    base_url="https://openrouter.ai/api/v1"
)

# Utility to detect applicable IPC section
def match_ipc_section(user_input):
    for keyword, data in ipc_sections.items():
        if keyword in user_input.lower():
            return data
    return None

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message", "")
    user_id = request.json.get("userId", "anonymous")

    if not user_input:
        return jsonify({"error": "Empty message"}), 400

    try:
        matched_section = match_ipc_section(user_input)

        system_prompt = (
            "You are Legal Saathi, a legal assistant trained on Indian laws. "
            "When a user describes a situation, identify which IPC section may apply, describe it simply, "
            "explain the legal penalty, and suggest clear next steps (like filing FIR, evidence needed, etc.). "
            "Avoid giving therapy or emotional support. Focus strictly on legal guidance."
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}
        ]

        response = openai_client.chat.completions.create(
            model="openai/gpt-3.5-turbo",
            messages=messages
        )

        bot_reply = response.choices[0].message.content.strip()

        # If relevant IPC section found, enhance reply
        if matched_section:
            section_info = (
                f"\n\n🔍 **Legal Match Found:**\n"
                f"• Section: {matched_section['section']}\n"
                f"• Description: {matched_section['description']}\n"
                f"• Penalty: {matched_section['penalty']}\n\n"
                f"📝 **Recommended Steps:**\n" +
                "\n".join(f"→ {step}" for step in matched_section['steps'])
            )
            bot_reply += section_info

        store_message(user_id, user_input, bot_reply)
        return jsonify({"reply": bot_reply})

    except Exception as e:
        print("❌ Error:", e)
        return jsonify({"error": str(e)}), 500

@app.route("/chat-history", methods=["GET"])
def chat_history():
    user_id = "test_user_123"
    messages = get_user_messages(user_id)
    return jsonify({"messages": messages})

if __name__ == "__main__":
    app.run(debug=True)
