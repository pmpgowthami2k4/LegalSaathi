ipc_sections = {
    "culpable homicide": {
        "section": "IPC Section 304",
        "description": "Punishment for culpable homicide not amounting to murder.",
        "penalty": "Imprisonment for life, or up to 10 years imprisonment and fine.",
        "steps": [
            "File an FIR at the nearest police station.",
            "Provide all available evidence (e.g., eyewitness accounts, forensic reports).",
            "Ensure the complaint clearly states the intent and circumstances leading to the act."
        ]
    },
    "attempt to murder": {
        "section": "IPC Section 307",
        "description": "Attempt to commit murder.",
        "penalty": "Up to 10 years imprisonment and fine; if hurt is caused, imprisonment for life.",
        "steps": [
            "Immediately report the incident to the police and file an FIR.",
            "Submit medical reports of injuries sustained.",
            "Collect and provide any evidence indicating the intent to kill."
        ]
    },
    "causing miscarriage": {
        "section": "IPC Section 312",
        "description": "Voluntarily causing a woman to miscarry without good faith to save her life.",
        "penalty": "Up to 3 years imprisonment, or fine, or both; if the woman is quick with child, up to 7 years imprisonment and fine.",
        "steps": [
            "Report the incident to the police with all relevant medical documentation.",
            "Provide statements from medical professionals if available.",
            "Ensure the complaint specifies the lack of good faith in the act."
        ]
    },
    "attempt to commit culpable homicide": {
        "section": "IPC Section 308",
        "description": "Attempt to commit culpable homicide not amounting to murder.",
        "penalty": "Up to 3 years imprisonment, or fine, or both; if hurt is caused, up to 7 years imprisonment and fine.",
        "steps": [
            "File an FIR detailing the incident and intent behind the act.",
            "Gather and submit any evidence of the attempt, including witness statements.",
            "Seek medical examination to document any injuries sustained."
        ]
    },
    "exposure and abandonment of child": {
        "section": "IPC Section 317",
        "description": "Exposure and abandonment of a child under twelve years by parent or person having care of it.",
        "penalty": "Up to 7 years imprisonment, or fine, or both.",
        "steps": [
            "Report the incident to child protection services and the police.",
            "Provide details about the child's condition and location found.",
            "Assist authorities in identifying the responsible individual."
        ]
    },
    "causing death of quick unborn child": {
        "section": "IPC Section 316",
        "description": "Causing death of a quick unborn child by an act amounting to culpable homicide.",
        "penalty": "Up to 10 years imprisonment and fine.",
        "steps": [
            "File an FIR with detailed medical reports indicating the cause of death.",
            "Include statements from medical professionals regarding the viability of the unborn child.",
            "Provide any evidence pointing to the intentional act leading to the death."
        ]
    },
    "concealment of birth": {
        "section": "IPC Section 318",
        "description": "Concealment of birth by secret disposal of the dead body.",
        "penalty": "Up to 2 years imprisonment, or fine, or both.",
        "steps": [
            "Report the discovery of the concealed body to the police immediately.",
            "Preserve the scene for forensic examination.",
            "Assist authorities with any information regarding potential suspects."
        ]
    },
    "act to prevent child being born alive": {
        "section": "IPC Section 315",
        "description": "Act done with intent to prevent child being born alive or to cause it to die after birth.",
        "penalty": "Up to 10 years imprisonment, or fine, or both.",
        "steps": [
            "File an FIR detailing the act and its consequences.",
            "Provide medical records and expert opinions supporting the claim.",
            "Include any evidence indicating the intent behind the act."
        ]
    },
    "criminal intimidation": {
        "section": "IPC Section 506",
        "description": "Criminal intimidation by threatening someone with injury or harm.",
        "penalty": "Up to 2 years imprisonment, or fine, or both; if threat is to cause death or grievous hurt, up to 7 years imprisonment, or fine, or both.",
        "steps": [
            "Report the threat to the police with all available details.",
            "Provide any evidence such as messages, recordings, or witness statements.",
            "Ensure the complaint specifies the nature and extent of the threat."
        ]
    },
    "cheating": {
        "section": "IPC Section 420",
        "description": "Cheating and dishonestly inducing delivery of property.",
        "penalty": "Up to 7 years imprisonment and fine.",
        "steps": [
            "File a complaint with the police including all transaction details.",
            "Submit evidence of the cheating act, such as documents or communications.",
            "Provide information about the accused's identity and whereabouts if known."
        ]
    },
    "rape": {
        "section": "IPC Section 376",
        "description": "Punishment for rape.",
        "penalty": "Rigorous imprisonment for not less than 10 years, which may extend to life, and fine.",
        "steps": [
            "Report the crime immediately to the nearest police station.",
            "Ensure a medical examination is conducted promptly.",
            "Provide a detailed statement and evidence to the police."
        ]
    },
    "kidnapping": {
        "section": "IPC Section 363",
        "description": "Punishment for kidnapping.",
        "penalty": "Up to 7 years imprisonment and fine.",
        "steps": [
            "File an FIR with details of the missing person.",
            "Share any last known locations, phone calls, or contacts.",
            "Cooperate with police investigation and share leads promptly."
        ]
    },
    "assault or criminal force to woman with intent to outrage her modesty": {
        "section": "IPC Section 354",
        "description": "Assault or criminal force to woman with intent to outrage her modesty.",
        "penalty": "Imprisonment from 1 to 5 years and fine.",
        "steps": [
            "Report the incident to the police immediately.",
            "Provide any supporting evidence (witnesses, CCTV footage).",
            "Request safety and legal protection if needed."
        ]
    },
    "dowry death": {
        "section": "IPC Section 304B",
        "description": "Death of a woman caused by burns or bodily injury within 7 years of marriage, related to dowry demand.",
        "penalty": "Imprisonment not less than 7 years, which may extend to life.",
        "steps": [
            "Report the death to police specifying dowry-related concerns.",
            "Collect and submit witness statements, photos, and medical evidence.",
            "Ensure inquest and autopsy are done by official authorities."
        ]
    },
    "wrongful restraint": {
        "section": "IPC Section 341",
        "description": "Wrongful restraint of any person.",
        "penalty": "Up to 1 month imprisonment, or fine up to ₹500, or both.",
        "steps": [
            "File a police complaint describing the situation.",
            "Mention the location and duration of restraint.",
            "Include witness testimony if available."
        ]
    },
    "grievous hurt": {
        "section": "IPC Section 325",
        "description": "Voluntarily causing grievous hurt.",
        "penalty": "Up to 7 years imprisonment and fine.",
        "steps": [
            "File an FIR and undergo medical examination.",
            "Submit medical reports as evidence of severity.",
            "Identify and report the assailant."
        ]
    },
    "criminal breach of trust": {
        "section": "IPC Section 406",
        "description": "Criminal breach of trust by a person entrusted with property.",
        "penalty": "Up to 3 years imprisonment, or fine, or both.",
        "steps": [
            "File a complaint detailing the breach of trust.",
            "Include transaction records and communications.",
            "Mention the entrusted items and nature of the agreement."
        ]
    },
    "house trespass": {
        "section": "IPC Section 448",
        "description": "Punishment for house trespass.",
        "penalty": "Up to 1 year imprisonment, or fine up to ₹1,000, or both.",
        "steps": [
            "Report the trespass to the police with time and location.",
            "Submit any CCTV footage or eyewitness accounts.",
            "Secure the premises to prevent future trespassing."
        ]
    },
    "public nuisance": {
        "section": "IPC Section 268",
        "description": "Causing public nuisance affecting health or safety of public.",
        "penalty": "Punishable under specific provisions depending on the act.",
        "steps": [
            "Report to local authorities or police with exact location.",
            "Mention how the act impacts public health or order.",
            "Provide photographic or video evidence if possible."
        ]
    },
    "defamation": {
        "section": "IPC Section 499",
        "description": "Making or publishing false statements to harm a person’s reputation.",
        "penalty": "Up to 2 years imprisonment, or fine, or both.",
        "steps": [
            "File a legal complaint in the court with evidence of defamation.",
            "Provide published material, social media screenshots, or recordings.",
            "Include witness testimonies if available."
        ]
    }
    
}
