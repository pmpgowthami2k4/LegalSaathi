document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const sidebar = document.getElementById("sidebar");

    if (localStorage.getItem("sidebarOpen") === "true") {
        sidebar.classList.add("active");
    }

    menuToggle.addEventListener("click", function () {
        sidebar.classList.toggle("active");
        localStorage.setItem("sidebarOpen", sidebar.classList.contains("active") ? "true" : "false");
    });
});

// Legal Chat Interface
const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

function appendMessage(sender, message) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", sender === "user" ? "user-message" : "bot-message");

    const messageText = document.createElement("p");
    messageText.innerText = message;
    messageDiv.appendChild(messageText);

    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendMessage() {
    const message = userInput.value.trim();
    if (message === "") return;

    appendMessage("user", message);
    userInput.value = "";

    try {
        const response = await fetch("http://127.0.0.1:5000/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ message: message })
        });

        const data = await response.json();
        appendMessage("bot", data.reply || "Sorry, I couldn't provide legal assistance for that.");
    } catch (error) {
        console.error("Error:", error);
        appendMessage("bot", "Oops! Something went wrong. Please try again.");
    }
}

// Legal Tips Modal
async function showLegalTips() {
    try {
        const response = await fetch("http://127.0.0.1:5000/legal-tips");
        const data = await response.json();

        document.getElementById("legal-tips-content").innerHTML = `
            <div class="legal-columns">
                <div class="column">
                    <h3>📜 Legal Tip</h3>
                    <p>${data.tip}</p>
                </div>
                <div class="column">
                    <h3>📚 Resource</h3>
                    <p>${data.resource}</p>
                </div>
                <div class="column">
                    <h3>⚖️ Case Study</h3>
                    <p>${data.case}</p>
                </div>
            </div>
        `;

        document.getElementById("legal-tips-modal").style.display = "block";
    } catch (error) {
        console.error("Error fetching legal tips:", error);
        alert("Could not fetch legal tips. Please try again.");
    }
}

function closeLegalTips() {
    document.getElementById("legal-tips-modal").style.display = "none";
}

// Custom User Legal List
function addToLegalList(type) {
    const input = document.getElementById(`${type}-input`);
    const value = input.value.trim();
    if (value === "") return;

    const list = document.getElementById(`${type}-list`);
    const listItem = document.createElement("li");
    listItem.classList.add("list-item");

    const textSpan = document.createElement("span");
    textSpan.textContent = value;

    const deleteBtn = document.createElement("span");
    deleteBtn.classList.add("delete-btn");
    deleteBtn.innerHTML = "✖";
    deleteBtn.onclick = () => list.removeChild(listItem);

    listItem.appendChild(textSpan);
    listItem.appendChild(deleteBtn);
    list.appendChild(listItem);

    input.value = "";
}

