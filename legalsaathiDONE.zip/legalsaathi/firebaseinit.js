// firebase-init.js
const firebaseConfig = {
    apiKey: "AIzaSyDliF9vwl18NBTrYSgMxBrTJcinzfphg3g",
    authDomain: "therapybot-22b03.firebaseapp.com",
    projectId: "therapybot-22b03",
    storageBucket: "therapybot-22b03.appspot.com",
    messagingSenderId: "356471372007",
    appId: "1:356471372007:web:96f9485d4e58e60ef5ca42"
  };
  
  firebase.initializeApp(firebaseConfig);
  